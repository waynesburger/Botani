import { Component } from '@angular/core';

import { NavController, LoadingController } from 'ionic-angular';
import { Auth, Logger } from 'aws-amplify';

import { TabsPage } from '../tabs/tabs';
import { SignupPage } from '../signup/signup';
import { ConfirmSignInPage } from '../confirmSignIn/confirmSignIn';
import { LoginInfoProvider } from '../../providers/login-info/login-info';

import {Http} from '@angular/http';

const logger = new Logger('Login');

export class LoginDetails {
  username: string;
  password: string;

}

@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {
  
  public loginDetails: LoginDetails;
  private saveLogIn;

  constructor(public navCtrl: NavController,
              public loadingCtrl: LoadingController, saveLogIn : LoginInfoProvider) {
    this.loginDetails = new LoginDetails(); 
    this.saveLogIn = saveLogIn
  }

  login() {
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();

    let details = this.loginDetails;
    logger.info('login..');
    Auth.signIn(details.username, details.password)
      .then(user => {
        logger.debug('signed in user', user);
          /*this.http.get('http://newtestr-env.us-west-2.elasticbeanstalk.com/.php')
            .map(user =>
                {
                   return user.json()
                }).subscribe(details.userId = user);*/
          this.saveLogIn.updateUsername(details.username);
          this.navCtrl.setRoot(TabsPage);
       // }
      })
      .catch(err => logger.debug('errrror', err))
      .then(() => loading.dismiss());
  }

  signup() {
    this.navCtrl.push(SignupPage);
  }

}
